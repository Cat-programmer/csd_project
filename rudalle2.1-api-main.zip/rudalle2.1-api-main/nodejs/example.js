const { generate } = require(`./api.js`);

generate(`cat`,`./`)