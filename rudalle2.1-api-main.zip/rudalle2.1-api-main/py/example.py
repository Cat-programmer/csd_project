from api import generate as kandinsky

kandinsky('cat','./','')
