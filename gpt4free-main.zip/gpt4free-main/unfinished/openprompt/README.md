https://openprompt.co/

to do:
- finish integrating email client
- code refractoring